
import 'package:device_utils/log/log.dart';
import 'package:flutter/foundation.dart';

class CLog{

  static String Tag = 'CxPlayerD';

  static void d(String msg){
    if(kDebugMode){
      debugPrint("[$Tag] DEBUG/${_getCaller()}:$msg");////uplog可读性差，Debug下还是用自己的
    }
    //release环境下，使用智家公共日志工具，为了他们测试、客服取日志的统一
    if(kReleaseMode) {
      DevLogger.debug(tag: "[$Tag]", msg: msg);
    }
  }

  static void i(String msg){
    if(kDebugMode) {
      debugPrint("[$Tag] INFO/${_getCaller()}:$msg");
    }
    if(kReleaseMode) {
      DevLogger.info(tag: "[$Tag]", msg: msg);
    }
  }

  static void e(String msg,[Object? e]){
    if(kDebugMode) {
      debugPrint("[$Tag] ERROR/${_getCaller()}:$msg ${e.toString()}");
    }
    if(kReleaseMode) {
      DevLogger.error(tag: "[$Tag]", msg: "$msg ${e.toString()}");
    }
  }

  static String _getCaller(){
    String r = '';
    try {
      StackTrace s = StackTrace.current;
      //print("========\n${s}");
      final split = s.toString().split('\n');
      if (split.length > 2) {
        String s = split[2];
        int last = s.lastIndexOf(':');
        String lineNum = s.substring(s.lastIndexOf(':', last - 1) + 1, last);
        String pre = s.substring(s.indexOf("  "), s.indexOf('('));
        String className = pre.split(".")[0].trim();
        //print("========|${className}|$lineNum|");
        r = "$className:$lineNum:";
      }
    }catch(e){
      //print('=========e:$e');
      return r;
    }
    return r;
  }

}
