import 'package:flutter/services.dart';
import 'package:cx_player/cx_player.dart';
import '../impl/CLog.dart';
import '../impl/device_live_info_repo.dart';

const qihooAppId = 'Haier_App';
const channelNameBase = "com.haier.uhome/cx-player";

class PlayStateMap {
  static final PlayStateMap _instance = PlayStateMap._();

  final Map<String, PlayState> _playStateMap = {};

  PlayStateMap._() {
    for (PlayState v in PlayState.values) {
      _playStateMap[v.toString().split('.').last] = v;
    }
  }

  static PlayStateMap instance() {
    return _instance;
  }

  PlayState? convert(String? state) {
    return _playStateMap[state];
  }
}

class FlutterPlayerErrorInfo {
  static const String DeviceLiveInfoInvalid = "DeviceInfoInvalid";
}

class CommonMethodChannel {
  static MethodChannel baseChannel = const MethodChannel(channelNameBase);

  static setCommonMethodCallHandler() {
    baseChannel.setMethodCallHandler((call) async {
      CLog.i("[CommonMethodChannel] baseChannel onMethodCall method:${call.method} arguments:${call.arguments}");
      switch (call.method) {
        case "getDeviceLiveInfo":
          {
            final deviceId = call.arguments['deviceId'];
            return await DeviceLiveInfoRepo.instance.getDeviceLiveInfo(deviceId, forceRemote: true);
          }
      }
    });
  }
}
