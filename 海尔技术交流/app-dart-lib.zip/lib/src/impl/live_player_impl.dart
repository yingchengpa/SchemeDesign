import 'dart:async';

import 'package:cx_player/cx_player.dart';
import 'package:qihoo_player/src/impl/CxTexture.dart';
import 'package:qihoo_player/src/impl/base_player_impl.dart';
import 'package:qihoo_player/src/impl/CLog.dart';
import 'package:qihoo_player/src/impl/common.dart';
import 'package:qihoo_player/src/impl/constants.dart';
import 'package:qihoo_player/src/impl/device_live_info_repo.dart';
import 'package:qihoo_player/src/utils/player_tracker.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

class LivePlayer extends BasePlayer implements ILivePlayer {
  bool _isDual = false;
  bool _isReverse = false;
  StreamController<double>? _talkVolumeStream;

  bool _isTalking = false;

  LivePlayer(String deviceId, {bool isDual = false, bool isReverse = false})
      : _isDual = isDual,
        _isReverse = isReverse,
        super(deviceId, PlayerType.live) {
    _init();
  }

  Future<void> _init() async {
    CLog.i('[LivePlayer] $deviceId _init isDual:$_isDual isReverse:$_isReverse');
    isInitRunning = true;
    try {
      var deviceLiveInfo = await DeviceLiveInfoRepo.instance.getDeviceLiveInfo(deviceId);
      //CLog.d('$_deviceId deviceLiveInfo:$deviceLiveInfo');
      if (deviceLiveInfo == null) {
        isInitRunning = false;
        currentPlayException = BasePlayException(code: cxplayerDeviceInfoInviladCode, info: 'device live info is null');
        updatePlayState(PlayState.error);
        CLog.e('[LivePlayer] $deviceId _init deviceLiveInfo is null!');
        return;
      }
      CommonMethodChannel.baseChannel.invokeMethod('preConnect', deviceId).catchError((e) {
        CLog.e('[LivePlayer] $deviceId preConnect error:', e);
      });
      //TODO 创建播放器的时候，将设备最大分辨率穿过去，设置的surface cache上
      var createParam = {
        'deviceId': deviceId,
        'isDual': _isDual,
        'deviceLiveInfo': deviceLiveInfo,
        'isReverse': _isReverse
      };
      CLog.i('[LivePlayer] $deviceId _init call createLivePlayer createParam:$createParam');
      var value = await CommonMethodChannel.baseChannel.invokeMethod<List<Object?>?>('createLivePlayer', createParam);
      CLog.i("[LivePlayer] $deviceId _init createLivePlayer result value:$value PlayState: $playState");
      if (value != null) {
        textureId = value[0] as int;
        if (_isDual) {
          subTextureId = value[1] as int;
          subTexture ??= CxTexture();
          // subTexture?.setTextureId(subTextureId);
        }
      }
      methodChannel = MethodChannel("$channelNameBase/method/$textureId");
      //TODO 如果已经停止播放了，这里才来，造可能造成同步异常？我们先认为这个速度很快，一般不会错误
      // methodChannelFutureCompleter.complete(_methodChannel);
      subscribeWithEventChannelName('$channelNameBase/event/$textureId');
      isInitRunning = false;
      isInited = true;
      methodChannelFutureCompleter.complete(methodChannel);
      if (getCurrentPlayState() == PlayState.loading) {
        _startPlayInternal();
      }
    } catch (e) {
      CLog.e("[LivePlayer] $deviceId _init error:", e);
      isInitRunning = false;
      currentPlayException = BasePlayException(code: cxplayerInitErrorCode, info: 'Live player init failed');
      playStateStream.add(PlayState.error);
    }
  }

  @override
  void onExtraEvent(Map<String, dynamic> eventMap) {
    if (eventMap.containsKey("talkingVolume")) {
      double volume = eventMap["talkingVolume"];
      _talkVolumeStream?.add(volume);
    }
  }

  @override
  Widget? getExtraVideoView({int serialNum = 2}) {
    //TODO 不反复新建Texture，不过我看官方demo也是反复新建Texture
    CLog.i('[LivePlayer] $deviceId getExtraVideoView isDual:$_isDual, _isReverse:$_isReverse');
    if (!_isDual) {
      return null;
    }
    subTexture ??= CxTexture();
    if (subTextureId != -1) {
      subTexture?.setTextureId(subTextureId);
    }
    return subTexture;
  }

  @override
  Size getExtraVideoSize({int serialNum = 2}) {
    return subVideoSize;
  }

  @override
  void startPlay() {
    bool needLiveInfo = getCurrentPlayState() == PlayState.error &&
        (currentPlayException.code == cxplayerDeviceInfoInviladIOS || currentPlayException.code == cxplayerDeviceInfoInviladCode || currentPlayException.code == cxplayerDeviceInfoExpiredCode);
    CLog.i(
        "[LivePlayer] $deviceId startPlay isInited:$isInited isInitRunning:$isInitRunning currentPlayState:${getCurrentPlayState()} needLiveInfo:${needLiveInfo}");
    updatePlayState(PlayState.loading);
    printFlag = false;
    if (isInited) {
      if (needLiveInfo) {
        retryPlayWithDeviceLiveInfo();
      } else {
        _startPlayInternal();
      }
    } else {
      if (!isInitRunning) {
        _init();
      } else {
        CLog.i('[LivePlayer] $deviceId startPlay init is running, waiting for init complete');
      }
    }
  }

  void _startPlayInternal() {
    CLog.i("[LivePlayer] $deviceId _startPlayInternal");
    getMethodChannel().then((channel) {
      PlayerTracker.trackTimeConsumeNode(Node.onStartPlay, this);
      channel?.invokeMethod("startPlay").catchError((error) {
        CLog.e('[LivePlayer] $deviceId startPlay error:', error);
      });
    });
  }

  @override
  Stream<double> startTalking() {
    CLog.i("[LivePlayer] $deviceId startTalking");
    PlayerTracker.trackFeatureUseage(talkFeature);
    _talkVolumeStream ??= StreamController<double>.broadcast();
    getMethodChannel().then((channel) {
      CLog.i("[LivePlayer] $deviceId startTalking call native method");
      _isTalking = true;
      channel?.invokeMethod("startTalking").then((value) {
        if (value != null && value == 2) {
          _isTalking = false;
        CLog.e('[LivePlayer] startTalking error: session be used');
          _talkVolumeStream!.addError(BasePlayException(code: value, info: 'session be used'));
        }
      }).catchError((error) {
        _isTalking = false;
        CLog.e('[LivePlayer] startTalking error: $error');
        PlayerTracker.trackExceptionWithError(ErrorType.talk, error);
        _talkVolumeStream!.addError(error);
      });
    }).catchError((error) {
      _talkVolumeStream!.addError(error);
    });
    return _talkVolumeStream!.stream;
  }

  @override
  void stopTalking() {
    CLog.i("[LivePlayer] $deviceId stopTalking isTalking:$_isTalking");
    _isTalking = false;
    _talkVolumeStream?.close();
    _talkVolumeStream = null;
    getMethodChannel().then((channel) {
      CLog.i("[LivePlayer] $deviceId stopTalking call native method");
      channel?.invokeMethod("stopTalking").then((value) {
        CLog.i("[LivePlayer] $deviceId stopTalking native method success");
      }).catchError((error) {
        CLog.e('[LivePlayer] $deviceId stopTalking error:', error);
        PlayerTracker.trackExceptionWithError(ErrorType.talk, error);
      });
    });
  }

  @override
  bool isTalking() {
    return _isTalking;
  }

  @override
  void setMagicVoice(MagicVoice magicVoice) {
    String voice = 'normal';
    if (magicVoice == MagicVoice.joker) {
      voice = 'joker';
    } else if (magicVoice == MagicVoice.uncle) {
      voice = 'uncle';
    }
    CLog.i('[LivePlayer] $deviceId setMagicVoice voice:$voice');
    getMethodChannel().then((channel) {
      CLog.i("[LivePlayer] $deviceId setMagicVoice call native method");
      channel?.invokeMethod('setMagicVoice', voice).then((value) {
        CLog.i('[LivePlayer] $deviceId setMagicVoice success');
      }).catchError((error) {
        CLog.e('[LivePlayer] $deviceId setMagicVoice error:', error);
      });
    });
  }
}
