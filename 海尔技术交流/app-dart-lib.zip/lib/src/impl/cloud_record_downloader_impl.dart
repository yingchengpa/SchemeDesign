import 'dart:async';

import 'package:cx_player/cx_player.dart';
import 'package:qihoo_player/src/impl/CLog.dart';
import 'package:qihoo_player/src/impl/common.dart';
import 'package:qihoo_player/src/impl/constants.dart';
import 'package:qihoo_player/src/utils/player_tracker.dart';
import 'package:flutter/services.dart';

int _cloudRecordDownloaderId = 0;

class CloudRecordDownloader implements ICloudRecordDownloader {
  final String url;
  final String dirPath;

  final int _downloaderId;

  final Completer<MethodChannel?> _methodChannelFutureCompleter = Completer();
  MethodChannel? _methodChannel;
  EventChannel? _eventChannel;

  StreamController<DownloadState>? _stateStream;
  StreamController<double>? _progressStream;

  double _currentProgress = 0;
  DownloadState _currentState = DownloadState.idle;
  bool _isDestroyed = false;

  CloudRecordDownloader(this.url, this.dirPath)
      : _downloaderId = ++_cloudRecordDownloaderId,
        assert(url.isNotEmpty, 'Downloader url can not be empty!'),
        assert(dirPath.isNotEmpty, 'Downloader can not be empty!') {
    _init();
  }

  Future<void> _init() async {
    CLog.i('[CloudRecordDownloader] downloader$_downloaderId _init url:$url dirPath:$dirPath');
    try {
      final params = {'url': url, 'dirPath': dirPath, 'downloaderId': _downloaderId};
      await CommonMethodChannel.baseChannel.invokeMethod('createCloudRecordDownloader', params);
      _methodChannel = MethodChannel('$channelNameBase/method/downloader/$_downloaderId');
      _eventChannel = EventChannel('$channelNameBase/event/downloader/$_downloaderId');
      subscribeDownloadEvent();
      _methodChannelFutureCompleter.complete(_methodChannel);
      CLog.i('[CloudRecordDownloader] downloader$_downloaderId _init success');
    } catch (error) {
      CLog.e('[CloudRecordDownloader] downloader$_downloaderId _init error:', error);
      PlayerTracker.trackExceptionWithError(ErrorType.cloudRecordDownload, error);
    }
  }

  void subscribeDownloadEvent() {
    CLog.i('[CloudRecordDownloader] downloader$_downloaderId subscribeDownloadEvent');
    _eventChannel?.receiveBroadcastStream().listen((event) {
      CLog.d('[CloudRecordDownloader] downloader$_downloaderId receive event: $event');
      final Map<String, dynamic> eventMap = (event as Map<dynamic, dynamic>).cast<String, dynamic>();
      final eventName = eventMap[kEventName] as String;
      if (eventName == kDownloadProgress) {
        _currentProgress = (eventMap[kEventData] / 1.0) as double;
        _progressStream?.add(_currentProgress);
      } else if (eventName == kDownloadState) {
        _currentState = _DownloadStateMap.instance().convert(eventMap[kEventData] as String)!;
        _stateStream?.add(_currentState);
        if (_currentState == DownloadState.error) {
          getException().then((exception) {
            CLog.e('[CloudRecordDownloader] downloader$_downloaderId DownloadState error code:${exception.code} msg:${exception.message}');
            PlayerTracker.trackException(
                ErrorType.cloudRecordDownload, exception.code.toString(), "", exception.message);
          }, onError: (e) {});
        }
      }
    });
  }

  @override
  void cancel() {
    CLog.i('[CloudRecordDownloader] downloader$_downloaderId cancel');
    _getMethodChannel().then((channel) {
      channel?.invokeMethod('cancel').then((value) {
        CLog.i('[CloudRecordDownloader] downloader$_downloaderId cancel success');
      }).catchError((error) {
        CLog.e('[CloudRecordDownloader] downloader$_downloaderId cancel error:', error);
      });
    });
  }

  @override
  void destroy() {
    CLog.i('[CloudRecordDownloader] downloader$_downloaderId destroy');
    _getMethodChannel().then((channel) {
      channel?.invokeMethod('destroy').then((value) {
        _isDestroyed = true;
        CLog.i('[CloudRecordDownloader] downloader$_downloaderId destroy success');
      }).catchError((error) {
        CLog.e('[CloudRecordDownloader] downloader$_downloaderId destroy error:', error);
      });
    });
  }

  @override
  DownloadState getCurrentDownloadState() {
    return _currentState;
  }

  @override
  double getCurrentProgress() {
    return _currentProgress;
  }

  @override
  Future<DownloadException> getException() async {
    final channel = await _getMethodChannel();
    final exceptionInfo = await channel?.invokeMethod('getException');
    final exceptionMap = (exceptionInfo as Map<dynamic, dynamic>).cast<String, dynamic>();
    return DownloadException(exceptionMap[kErrorCode] as int, exceptionMap[kErrorMsg] as String);
  }

  @override
  Stream<DownloadState> observeDownloadState() {
    _stateStream ??= StreamController<DownloadState>.broadcast();
    return _stateStream!.stream;
  }

  @override
  Stream<double> observeProgress() {
    _progressStream ??= StreamController<double>.broadcast();
    return _progressStream!.stream;
  }

  @override
  Future<String> startDownload() async {
    PlayerTracker.trackFeatureUseage(downloadFeature);
    CLog.i('[CloudRecordDownloader] downloader$_downloaderId startDownload');
    try {
      final channel = await _getMethodChannel();
      final path = await channel?.invokeMethod('startDownload');
      CLog.i('[CloudRecordDownloader] downloader$_downloaderId startDownload success path:$path');
      return path;
    } catch (e) {
      CLog.e('[CloudRecordDownloader] downloader$_downloaderId startDownload error:', e);
      PlayerTracker.trackExceptionWithError(ErrorType.cloudRecordDownload, e);
      return "";
    }
  }

  Future<MethodChannel?> _getMethodChannel() {
    if (_isDestroyed) {
      CLog.e('[CloudRecordDownloader] downloader getMethodChannel but has destroyed, downloaderId: $_downloaderId');
      return Future.value(null);
    }

    if (_methodChannel != null) {
      return Future.value(_methodChannel);
    }
    return _methodChannelFutureCompleter.future;
  }
}

class _DownloadStateMap {
  static final _DownloadStateMap _instance = _DownloadStateMap._();

  final Map<String, DownloadState> _stateMap = {};

  _DownloadStateMap._() {
    for (DownloadState v in DownloadState.values) {
      _stateMap[v.toString().split('.').last] = v;
    }
  }

  static _DownloadStateMap instance() {
    return _instance;
  }

  DownloadState? convert(String? state) {
    return _stateMap[state];
  }
}
