import 'dart:async';

import 'package:cx_player/cx_player.dart' hide kPlayerEvent, kPlayerVideoSizeChanged, kPlayerStuck;
import 'package:qihoo_player/src/impl/CLog.dart';
import 'package:qihoo_player/src/impl/CxTexture.dart';
import 'package:qihoo_player/src/impl/common.dart';
import 'package:qihoo_player/src/impl/constants.dart';
import 'package:qihoo_player/src/impl/device_live_info_repo.dart';
import 'package:qihoo_player/src/impl/live_player_impl.dart';
import 'package:qihoo_player/src/utils/player_tracker.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:network/isonline.dart';
import 'package:network/network.dart';
import 'package:plugin_device/model/common_models.dart';
import 'package:plugin_device/model/device_info_model.dart';
import 'package:plugin_device/plugin/updevice_plugin.dart';

abstract class BasePlayer implements IPlayer {
  /// 一次运行期间全局唯一, 是否首次直播播放
  static bool isFirstLivePlay = true;

  // 初始化状态
  @protected
  bool isInitRunning = false;
  @protected
  bool isInited = false;

  String deviceId;
  DeviceInfoModel? deviceInfo;
  final String playerType;

  // Channel

  /// 创建播放器时,内部存在异步_init方法,业务层调用create之后立即调用播放器其他方法时,
  /// 此时_init还没执行完,原生侧channel还没创建,导致调不到原生侧方法
  @protected
  final Completer<MethodChannel> methodChannelFutureCompleter = Completer();

  // 需要子类初始化成功后赋值
  @protected
  MethodChannel? methodChannel;

  // 子类初始化成功后调用subscribeWithEventChannelName()方法
  @protected
  StreamSubscription? eventSubscription;

  // 时间监听器
  @protected
  final StreamController<PlayState> playStateStream = StreamController<PlayState>.broadcast();
  @protected
  final StreamController<int> playProgressStream = StreamController<int>.broadcast();
  @protected
  final StreamController<BasePlayEvent> playEventStream = StreamController<BasePlayEvent>.broadcast();
  @protected
  final StreamController<int> bitrateStream = StreamController<int>.broadcast();
  @protected
  StreamController<void>? recordStream;
  @protected
  final StreamController<int> playTalkingVolumeStream = StreamController<int>.broadcast();

  // 状态
  @protected
  PlayState playState = PlayState.idle;
  @protected
  BasePlayException currentPlayException = BasePlayException.noneException;
  @protected
  bool deviceLiveInfoRetried = false;
  @protected
  int textureId = -1;
  @protected
  final CxTexture cxTexture = CxTexture();
  @protected
  int subTextureId = -1;
  @protected
  CxTexture? subTexture;
  @protected
  Size videoSize = const Size(0, 0);
  @protected
  Size subVideoSize = const Size(0, 0);
  @protected
  int currentProgress = 0;
  @protected
  bool isDestroyed = false;
  @protected
  bool printFlag = false;
  @protected
  int duration = 0;
  @protected
  int currentVolume = 0;

  VideoDefinition _currentVideoDefinition = VideoDefinition.HD;
  bool _isRecording = false;
  bool _isMute = false;
  bool _isStuck = false;

  BasePlayer(this.deviceId, this.playerType) {
    if (deviceId != 'VodPlayer') {
      UpDevicePlugin.getDeviceInfoById(deviceId).then((device) => deviceInfo = device);
    }
  }

  Future<MethodChannel?> getMethodChannel() {
    if (isDestroyed) {
      CLog.e('[BasePlayer] $deviceId getMethodChannel but player has destroyed: $deviceId');
      return Future.value(null);
    }
    if (methodChannel != null) {
      return Future.value(methodChannel);
    }

    return methodChannelFutureCompleter.future;
  }

  /// 事件回调定义:
  /// ```JSON
  /// {
  ///   "eventName": "playerEvent",
  ///   "eventType": "progress",
  ///   "eventData": {"progress": 42, "duration": 180}
  /// }
  /// ```
  void subscribeWithEventChannelName(String channelName) {
    final eventChanel = EventChannel(channelName);
    eventSubscription = eventChanel.receiveBroadcastStream().listen((value) {
      final Map<String, dynamic> eventMap = (value as Map<dynamic, dynamic>).cast<String, dynamic>();
      String eventName = eventMap[kEventName];
      String eventType = eventMap[kEventType];
      if (eventType != kPlayerProgress && eventType != kPlayerBitrate) {
        CLog.d('[BasePlayer] $deviceId onEventChannel value:$value');
      }
      if (eventName == kPlayerEvent) {
        onPlayerEvent(eventMap);
        return;
      }
      if (eventName == kRecordEvent) {
        onRecordEvent(eventMap);
        return;
      }
      if (eventName == kSnapshotEvent) {
        onSnapshotEvent(eventMap);
        return;
      }
      onExtraEvent(eventMap);
    });
  }

  /// 播放器回调事件处理
  void onPlayerEvent(Map<String, dynamic> eventMap) {
    final eventType = eventMap[kEventType] as String;
    Map<String, dynamic>? eventData;
    if (eventMap.containsKey(kEventData)) {
      eventData = (eventMap[kEventData] as Map<dynamic, dynamic>).cast<String, dynamic>();
    }
    if (eventType == kPlayerProgress) {
      int progress = int.parse(eventData![kPlayerProgress]);
      currentProgress = progress;
      if (eventData.containsKey(kPlayerDuration)) {
        duration = int.parse(eventData[kPlayerDuration]);
      }
      playProgressStream.add(progress);
    } else if (eventType == kPlayerState) {
      onPlayStateEvent(eventData!);
    } else if (eventType == kPlayerBitrate) {
      final bitrate = eventData![kPlayerBitrate] as int;
      bitrateStream.add(bitrate);
    } else if (eventType == kPlayerVideoSizeChanged) {
      onVideoSizeChangedEvent(eventData!);
    } else if (eventType == kPlayerStuck) {
      _isStuck = true;
      playEventStream.add(VideoStuckEvent());
    } else if (eventType == kPlayerTalkingVolume) {
      int volume = int.parse(eventData![kPlayerTalkingVolume]);
      playTalkingVolumeStream.add(volume);
    } else {
      playEventStream.add(BasePlayEvent(eventMap[kEventName], eventMap[kEventType], eventData: eventMap[kEventData]));
    }
  }

  void onPlayStateEvent(Map<String, dynamic> eventData) {
    final playState = PlayStateMap.instance().convert(eventData[kPlayerState]);
    BasePlayException? exception;
    if (playState == PlayState.error) {
      final err = (eventData[kPlayerError] as Map<dynamic, dynamic>).cast<String, dynamic>();
      exception = BasePlayException(code: err[kErrorCode], info: err[kErrorMsg], detail: err[kErrorDetail]);
      CLog.e('[BasePlayer] $deviceId onPlayStateEvent error,exception: $exception');
      currentPlayException = exception;
      if (currentPlayException.code == cxplayerDeviceInfoInviladIOS || currentPlayException.code == cxplayerDeviceInfoInviladCode || currentPlayException.code == cxplayerDeviceInfoExpiredCode) {
        // 开流失败,iOS返回错误码110005, Android返回910002/910003
        //开流信息过期
        DeviceLiveInfoRepo.instance.deleteDeviceLiveInfoCache(deviceId); //过期了就要把缓存信息删除
        CLog.i("[BasePlayer] $deviceId onPlayStateEvent DeviceInfoExpired deviceLiveInfoRetried:$deviceLiveInfoRetried");
        if (!deviceLiveInfoRetried) {
          //没有重试过久自动重试1次
          deviceLiveInfoRetried = true;
          retryPlayWithDeviceLiveInfo();
          return; //自动重试就不往外抛异常
        }
      }

      checkPlayError().then((e) {
        PlayerTracker.trackSuccessRate(Stage.play, this, exception: e ?? currentPlayException);
        if (this is LivePlayer) {
          isFirstLivePlay = false;
        }
        // 正常的错误类型不上报，只统计bug性质的报错
        if (e is! PlayNetworkException && e is! PlayOfflineException && e is! PlayPrivateModeException) {
          PlayerTracker.trackException(
              ErrorType.play, exception?.code.toString() ?? "-1", exception?.info, exception?.detail);
        }
      }).catchError((e){
          CLog.e("[BasePlayer] $deviceId onPlayStateEvent checkPlayError error:",e);
      });
    }
    if (playState == PlayState.playing) {
      PlayerTracker.trackTimeConsumeNode(Node.onPlaying, this);
      PlayerTracker.trackSuccessRate(Stage.play, this);
      if (this is LivePlayer) {
        isFirstLivePlay = false;
      }
      deviceLiveInfoRetried = false;
      if (textureId != -1) {
        cxTexture.setTextureId(textureId);
      } else {
        CLog.e("[BasePlayer] $deviceId onPlayStateEvent textureId is invalid!");
      }

      if (subTextureId != -1) {
        subTexture?.setTextureId(subTextureId);
      }
    }
    if (playState != null) {
      updatePlayState(playState);
    }
  }

  void onRecordEvent(Map<String, dynamic> eventMap) {
    String eventType = eventMap[kEventType];
    if (eventType == kRecordError) {
      final eventData = (eventMap[kEventData] as Map<dynamic, dynamic>).cast<String, dynamic>();
      final errorInfo = (eventData[kRecordError] as Map<dynamic, dynamic>).cast<String, dynamic>();
      CLog.e(
          '[BasePlayer] $deviceId onRecordEvent error code:${errorInfo[kErrorCode]} msg:${errorInfo[kErrorMsg]} detail:${errorInfo[kErrorDetail]}');
      _isRecording = false;
      recordStream?.addError(errorInfo[kErrorDetail] ?? errorInfo[kErrorMsg]);
      recordStream?.close();
      recordStream = null;
    }
  }

  void onSnapshotEvent(Map<String, dynamic> eventMap) {}

  void onExtraEvent(Map<String, dynamic> eventMap) {}

  void onVideoSizeChangedEvent(Map<String, dynamic> eventData) {
    int width = eventData['width'];
    int height = eventData['height'];
    videoSize = Size(width.toDouble(), height.toDouble());
    if (height != 0) {
      cxTexture.setVideoRatio(width / height);
      if (cxTexture.rect != null) {
        cxTexture.zoomToRect(cxTexture.rect!, animated: cxTexture.zoomAnimated);
      }
    }

    if (eventData.containsKey('subWidth')) {
      int subWidth = eventData['subWidth'];
      int subHeight = eventData['subHeight'];
      subVideoSize = Size(subWidth.toDouble(), subHeight.toDouble());
      if (subHeight != 0) {
        subTexture?.setVideoRatio(subWidth / subHeight);
      }
    }
    playEventStream.add(VideoSizeChangedEvent());
    final eventType = eventData['eventType'];
    if (eventType == "VideoSizeChangedEvent") {
    } else if (eventType == "PlayStuckEvent") {
      playEventStream.add(VideoStuckEvent());
    }
  }

  void updatePlayState(PlayState playState) {
    // 状态变化需要发送状态
    bool sendEvent = this.playState != playState;
    // 从卡顿中恢复也需要发送状态
    sendEvent |= (playState == PlayState.playing && _isStuck);
    _isStuck = playState == PlayState.playing;

    if (sendEvent) {
      CLog.i('[BasePlayer] $deviceId _updatePlayState:$playState');
      this.playState = playState;
      if (!playStateStream.isClosed && !playStateStream.isPaused) {
        playStateStream.add(playState);
      }
    }
  }

  Future<void> retryPlayWithDeviceLiveInfo() async {
    CLog.i("[BasePlayer] $deviceId retryPlayWithDeviceLiveInfo");
    try {
      String? deviceLiveInfo = await DeviceLiveInfoRepo.instance.getDeviceLiveInfo(deviceId, forceRemote: true);
      if (deviceLiveInfo == null) {
        CLog.e("[BasePlayer] $deviceId retryPlayWithDeviceLiveInfo deviceLiveInfo is null!");
        currentPlayException = BasePlayException(code: cxplayerDeviceInfoInviladCode, info: "DeviceLiveInfo is null!");
        updatePlayState(PlayState.error);
        return;
      }
      getMethodChannel().then((channel) => channel?.invokeMethod("retryPlayWithDeviceLiveInfo", deviceLiveInfo));
    } catch (e) {
      CLog.e('[BasePlayer] $deviceId retryPlayWithDeviceLiveInfo error:', e);
    }
  }

  @override
  @mustCallSuper
  void destroy() {
    CLog.i('[BasePlayer] $deviceId destroy');
    try {
      eventSubscription?.cancel();
      getMethodChannel().then((channel) => channel?.invokeMethod('destroy'));
      isDestroyed = true;
      playStateStream.close();
      playProgressStream.close();
      playEventStream.close();
      bitrateStream.close();
    } catch (e) {
      CLog.e('[BasePlayer] $deviceId destroy error: $e');
    }
  }

  @override
  PlayState getCurrentPlayState() {
    return playState;
  }

  @override
  Future<int> getCurrentProgress() async {
    final channel = await getMethodChannel();
    final progress = await channel?.invokeMethod<int>('getCurrentProgress');
    return progress ?? 0;
  }

  @override
  BasePlayException getPlayException() {
    return currentPlayException;
  }

  @override
  Future<VideoDefinition> getVideoDefinition() async {
    try {
      final channel = await getMethodChannel();
      final result = await channel?.invokeMethod('getVideoDefinition');
      if (result == 1) {
        return VideoDefinition.SD;
      } else {
        return VideoDefinition.HD;
      }
    } catch (e) {
      CLog.e('[BasePlayer] $deviceId setVideoDefinition error: $e');
      PlayerTracker.trackExceptionWithError(ErrorType.getVideoDefinition, e);
      return _currentVideoDefinition;
    }
  }

  @override
  Size getVideoSize() {
    return videoSize;
  }

  @override
  Widget getVideoView() {
    //TODO 不反复新建Texture，不过我看官方demo也是反复新建Texture
    CLog.i('[BasePlayer] $deviceId getVideoView');
    return cxTexture;
  }

  @override
  bool isMute() {
    return _isMute;
  }

  @override
  bool isRecording() {
    return _isRecording;
  }

  @override
  void mute() {
    CLog.i("[BasePlayer] $deviceId mute");
    _isMute = true;
    getMethodChannel().then((channel) {
      channel?.invokeMethod('mute').then((value) {});
    }).catchError((error) {
      CLog.e('[BasePlayer] $deviceId mute error: $error');
      throw error;
    });
  }

  @override
  Stream<int> observeBitrate() {
    return bitrateStream.stream;
  }

  @override
  Stream<BasePlayEvent> observePlayEvent() {
    return playEventStream.stream;
  }

  @override
  Stream<PlayState> observePlayState() {
    return playStateStream.stream;
  }

  @override
  Stream<int> observeProgress() {
    return playProgressStream.stream;
  }

  @override
  Stream<int> observeTalkingVolume() {
    return playTalkingVolumeStream.stream;
  }

  @override
  Future<bool> setVideoDefinition(VideoDefinition definition) async {
    PlayerTracker.trackFeatureUseage(definitionFeature);
    try {
      String def = definition.toString().split('.').last;
      final channel = await getMethodChannel();
      final result = await channel?.invokeMethod('setVideoDefinition', def);
      final ret = (result == 'true' || result == true);
      if (ret) {
        _currentVideoDefinition = definition;
      }
      return ret;
    } catch (e) {
      CLog.e('[BasePlayer] $deviceId setVideoDefinition error: $e');
      PlayerTracker.trackExceptionWithError(ErrorType.setVideoDefinition, e);
      return false;
    }
  }

  @override
  Future<String> snapShot(String dirPath) async {
    PlayerTracker.trackFeatureUseage(snapshotFeature);
    try {
      final channel = await getMethodChannel();
      final result = await channel?.invokeMethod('snapShot', dirPath);
      if (result  is! String) {
        return '';
      }
      return result;
    } catch (e) {
      PlayerTracker.trackExceptionWithError(ErrorType.snap, e);
      return "";
    }
  }

  @override
  void startPlay() {
    if (playState != PlayState.playing && playState != PlayState.loading) {
      PlayerTracker.trackTimeConsumeNode(Node.onStartPlay, this);
    }
  }

  @override
  Future<void> startRecord(String dirPath) async {
    CLog.i('[BasePlayer] $deviceId startRecord');
    PlayerTracker.trackFeatureUseage(recordFeature);
    try {
      recordStream ??= StreamController<void>.broadcast();
      final channel = await getMethodChannel();
      await channel?.invokeMethod('startRecord', dirPath);
      _isRecording = true;
    } catch (e) {
      PlayerTracker.trackExceptionWithError(ErrorType.record, e);
    }
  }

  @override
  void stopPlay() {
    CLog.i("[BasePlayer] $deviceId stopPlay");
    updatePlayState(PlayState.idle);
    getMethodChannel().then((channel) {
      channel?.invokeMethod("stopPlay").then((value) {}).catchError((error) {
        CLog.e('[BasePlayer] $deviceId stopPlay error:', error);
      });
    });
  }

  @override
  Future<String> stopRecord() async {
    final channel = await getMethodChannel();
    try {
      final result = await channel?.invokeMethod('stopRecord');
      _isRecording = false;
      if (result is! String) {
        CLog.e('[BasePlayer] $deviceId stopRecord result is not string!');
        return '';
      }
      return result;
    } catch (e) {
      CLog.e('[BasePlayer] $deviceId stopRecord error: $e');
      _isRecording = await channel?.invokeMethod('isRecording');
      PlayerTracker.trackExceptionWithError(ErrorType.record, e);
      rethrow;
    }
  }

  @override
  void unMute() {
    CLog.i("[BasePlayer] $deviceId unMute");
    _isMute = false;
    getMethodChannel().then((channel) {
      channel?.invokeMethod('unMute').then((value) {}).catchError((error) {
        CLog.e('[BasePlayer] $deviceId unMute error:', error);
      });
    });
  }

  // TODO 将PlayNetworkException、PlayOfflineException、PlayPrivateModeException 向外提供
  Future<BasePlayException?> checkPlayError() async {
    final NetworkStatus networkStatus = await Network.isOnline();
    bool isNetworkAvailable = networkStatus.isOnline;
    BasePlayException? exception;
    if (!isNetworkAvailable) {
      //是否没网
      exception = PlayNetworkException();
    } else {
      final da = await UpDevicePlugin.getDeviceAttributeById(deviceId);
      final isOnline = da.onlineStateV2 != OFFLINE;
      if (!isOnline) {
        //是否离线
        exception = PlayOfflineException();
      } else {
        //是否休眠
        for (var attr in da.attributes) {
          if (attr.name == "dormantMode") {
            final isDormant = attr.value.toLowerCase() == "true";
            if (isDormant) {
              exception = PlayPrivateModeException();
            }
            break;
          }
        }
      }
    }
    return exception;
  }
}
