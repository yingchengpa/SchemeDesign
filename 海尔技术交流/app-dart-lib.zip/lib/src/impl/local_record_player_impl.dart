import 'dart:async';

import 'package:cx_player/cx_player.dart';
import 'package:qihoo_player/src/impl/CxTexture.dart';
import 'package:qihoo_player/src/impl/base_player_impl.dart';
import 'package:qihoo_player/src/impl/CLog.dart';
import 'package:qihoo_player/src/impl/common.dart';
import 'package:qihoo_player/src/impl/constants.dart';
import 'package:qihoo_player/src/impl/device_live_info_repo.dart';
import 'package:qihoo_player/src/utils/player_tracker.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

class LocalRecordPlayer extends BasePlayer implements ILocalRecordPlayer {
  bool _isDual = false;
  bool _isReverse = false;
  bool _isSupportAov = false;
  double _currentSpeed = 1.0;

  LocalRecordPlayer(String deviceId, {bool isDual = false, bool isReverse = false,bool isSupportAov = false})
      : _isDual = isDual,
        _isReverse = isReverse,
        _isSupportAov = isSupportAov,
        super(deviceId, PlayerType.record) {
    _init();
  }

  Future<void> _init() async {
    CLog.i('[LocalRecordPlayer] $deviceId _init isDual:$_isDual isReverse:$_isReverse');
    isInitRunning = true;
    try {
      // Completer<MethodChannel> methodChannelFutureCompleter = Completer();
      // _methodFuture = methodChannelFutureCompleter.future;
      var deviceLiveInfo = await DeviceLiveInfoRepo.instance.getDeviceLiveInfo(deviceId);
      if (deviceLiveInfo == null) {
        isInitRunning = false;
        currentPlayException = BasePlayException(
            code: cxplayerDeviceInfoInviladCode, info: 'LocalRecordPlayer init error: Device Live Info is null');
        updatePlayState(PlayState.error);
        CLog.e('[LocalRecordPlayer] $deviceId _init deviceLiveInfo is null!');
        return;
      }

      //TODO 创建播放器的时候，将设备最大分辨率穿过去，设置的surface cache上
      var createParam = {
        'deviceId': deviceId,
        'isDual': _isDual,
        'deviceLiveInfo': deviceLiveInfo,
        'isReverse': _isReverse,
        'isSupportAov': _isSupportAov
      };
      CLog.i('[LocalRecordPlayer] $deviceId _init call createLocalRecordPlayer createParam:$createParam');
      var value =
          await CommonMethodChannel.baseChannel.invokeMethod<List<Object?>?>('createLocalRecordPlayer', createParam);
      CLog.i("[LocalRecordPlayer] $deviceId _init createLocalRecordPlayer result value:$value");
      if (value != null) {
        textureId = value[0] as int;
        if (_isDual) {
          subTextureId = value[1] as int;
          subTexture ??= CxTexture();
          // subTexture?.setTextureId(subTextureId);
        }
      }
      CLog.i("[LocalRecordPlayer] $deviceId _init textureId:$textureId subTextureId:$subTextureId");
      methodChannel = MethodChannel("$channelNameBase/method/$textureId");
      // methodChannelFutureCompleter.complete(_methodChannel); //TODO 如果已经停止播放了，这里才来，造可能造成同步异常？我们先认为这个速度很快，一般不会错误
      subscribeWithEventChannelName('$channelNameBase/event/$textureId');
      isInitRunning = false;
      isInited = true;
      methodChannelFutureCompleter.complete(methodChannel);
      if (getCurrentPlayState() == PlayState.loading) {
        CLog.i('[LocalRecordPlayer] $deviceId _init completed playState is loading, call _startPlayInternal');
        _startPlayInternal();
      }
    } catch (e) {
      CLog.e("[LocalRecordPlayer] $deviceId _init error:", e);
      isInitRunning = false;
      currentPlayException = BasePlayException(code: cxplayerInitErrorCode, info: 'LocalRecordPlayer init error: $e');
      playStateStream.add(PlayState.error);
    }
  }

  @override
  Future<List<Record>> getRecordList({int startMills = 0, int endMills = -1}) async {
    CLog.i("[LocalRecordPlayer] $deviceId getRecordList startMills:$startMills endMills:$endMills");
    try {
      PlayerTracker.trackSuccessRate(Stage.getRecordList, this);
      final param = {"startMills": startMills, "endMills": endMills};
      final channel = await getMethodChannel();
      List<dynamic> recordsMap = await channel?.invokeMethod("getRecordList", param);
      CLog.i("[LocalRecordPlayer] $deviceId getRecordList from native count:${recordsMap.length}");
      final recordList =
          recordsMap.cast<Map<dynamic, dynamic>>().map((item) => Record(item['startTime'], item['endTime'],recordType: item['recordType'])).toList();
      CLog.i("$deviceId getRecordList result size:${recordList.length}");
      return recordList;
    } catch (e) {
      CLog.e("[LocalRecordPlayer] $deviceId getRecordList error:", e);
      PlayerTracker.trackExceptionWithError(ErrorType.loadRecordList, e);

      BasePlayException exception;
      if (e is PlatformException) {
        exception = BasePlayException(code: int.parse(e.code), info: e.message ?? 'PlatformException');
      } else {
        exception = BasePlayException(code: -1, info: e.toString());
      }
      PlayerTracker.trackSuccessRate(Stage.getRecordList, this, exception: exception);
      return List.empty();
    }
  }

  @override
  Future<List<int>> getRecordDateList(int startMills, int endMills) async {
    CLog.i("[LocalRecordPlayer] $deviceId getRecordDateList startMills:$startMills endMills:$endMills");
    try {
      final params = {"startMills": startMills, "endMills": endMills};
      final channel = await getMethodChannel();
      List<dynamic> mills = await channel?.invokeMethod('getRecordDateList', params);
      CLog.i("[LocalRecordPlayer] $deviceId getRecordDateList result count:${mills.length}");
      return mills.cast<int>();
    } catch (e) {
      CLog.e("[LocalRecordPlayer] $deviceId getRecordDateList error:", e);
      PlayerTracker.trackExceptionWithError(ErrorType.loadRecordList, e);
      return List.empty();
    }
  }

  @override
  void seekTo(int mills) {
    CLog.i("[LocalRecordPlayer] $deviceId seekTo:$mills");
    getMethodChannel().then((channel) {
      channel?.invokeMethod("seekTo", mills).catchError((error) {
        CLog.e('[LocalRecordPlayer] $deviceId seekTo error:', error);
      });
    });
  }

  @override
  Widget? getExtraVideoView({int serialNum = 2}) {
    CLog.i('[LocalRecordPlayer] $deviceId getExtraVideoView isDual:$_isDual, _isReverse:$_isReverse');
    if (!_isDual) {
      return null;
    }
    subTexture ??= CxTexture();
    if (subTextureId != -1) {
      subTexture?.setTextureId(subTextureId);
    }
    return subTexture;
  }

  @override
  Size getExtraVideoSize({int serialNum = 2}) {
    return subVideoSize;
  }

  @override
  void startPlay() {
    bool needLiveInfo = getCurrentPlayState() == PlayState.error &&
        (currentPlayException.code == cxplayerDeviceInfoInviladIOS || currentPlayException.code == cxplayerDeviceInfoInviladCode || currentPlayException.code == cxplayerDeviceInfoExpiredCode);
    CLog.i(
        "[LocalRecordPlayer] $deviceId startPlay isInited:$isInited isInitRunning:$isInitRunning currentPlayState:${getCurrentPlayState()} needLiveInfo:$needLiveInfo");
    updatePlayState(PlayState.loading);
    printFlag = false;
    if (isInited) {
      if (needLiveInfo) {
        retryPlayWithDeviceLiveInfo();
      } else {
        _startPlayInternal();
      }
    } else {
      if (!isInitRunning) {
        _init();
      } else {
        CLog.i('[LocalRecordPlayer] $deviceId startPlay init is running, waiting for init complete');
      }
    }
  }

  void _startPlayInternal() {
    CLog.i("[LocalRecordPlayer] $deviceId _startPlayInternal");
    getMethodChannel().then((channel) {
      PlayerTracker.trackTimeConsumeNode(Node.onStartPlay, this);
      channel?.invokeMethod("startPlay").catchError((error) {
        CLog.e('[LocalRecordPlayer] $deviceId startPlay error: $error');
        updatePlayState(PlayState.error);
      });
    });
  }

  @override
  double getSpeed() {
    return _currentSpeed;
  }

  @override
  void pause() {
    CLog.i("[LocalRecordPlayer] $deviceId pause");
    getMethodChannel().then((channel) {
      channel?.invokeMethod('pause').then((value) {
        updatePlayState(PlayState.paused);
      }).catchError((error) {
        CLog.e('[LocalRecordPlayer] $deviceId pause error: $error');
      });
    });
  }

  @override
  void resume() {
    CLog.i("[LocalRecordPlayer] $deviceId resume");
    getMethodChannel().then((channel) {
      channel?.invokeMethod('resume').then((value) {
        updatePlayState(PlayState.playing);
      }).catchError((error) {
        CLog.e('[LocalRecordPlayer] $deviceId resume error: $error');
      });
    });
  }

  @override
  void setSpeed(double speed) {
    CLog.i("[LocalRecordPlayer] $deviceId setSpeed speed:$speed");
    getMethodChannel().then((channel) {
      channel?.invokeMethod('setSpeed', speed).then((value) {
        _currentSpeed = speed;
        CLog.i("[LocalRecordPlayer] $deviceId setSpeed success currentSpeed:$_currentSpeed");
      }).catchError((error) {
        CLog.e('[LocalRecordPlayer] $deviceId setSpeed error:', error);
        throw error;
      });
    });
  }

  @override
  void setVideoFramePlayInterval(int interval) {
    if(!this._isSupportAov){
      return;
    }
    CLog.i("$deviceId setVideoFramePlayInterval interval:$interval");
    getMethodChannel().then((channel) {
      channel?.invokeMethod('setVideoFramePlayInterval', interval).then((value) {
      }).catchError((error) {
        CLog.e('$deviceId setVideoFramePlayInterval error:', error);
        throw error;
      });
    });
  }
}
