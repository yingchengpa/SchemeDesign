import 'dart:ui';

import 'package:cx_player/cx_player.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'dart:math' as math;
import 'package:vector_math/vector_math_64.dart';

import 'CLog.dart';

class CxTexture extends StatefulWidget implements IVideoView{
  int? _textureId;
  CxTextureState? _state;
  double _videoRatio = 16/9;
  BoxFit _fit = BoxFit.none;
  Rect? _rect;
  bool _zoomAnimated = true;

  CxTexture({super.key,int? textureId}) : _textureId = textureId;

  @override
  State<CxTexture> createState(){
    _state = CxTextureState();
    return _state!;
  }

  Rect? get rect => _rect;
  bool get zoomAnimated => _zoomAnimated;

  setTextureId(int textureId){
    //CLog.d("setTextureId:$textureId state2:$state");
    if(_textureId != textureId) {
      _textureId = textureId;
      if(_state?.mounted == true){
        _state?.setState(() {
          _textureId = textureId;
        });
      }
    }
  }

  @override
  void setFit(BoxFit fit) {
    _fit = fit;
    _state?._correctAndFit();
  }

  @override
  void setVideoRatio(double ratio) {
    _videoRatio = ratio;
    _state?._correctAndFit();
  }

  @override
  void zoomToRect(Rect rect, {bool animated = true}) {
    _rect = rect;
    _zoomAnimated = animated;
    _state?._zoomToRect(rect, animated: animated);
  }

  @override
  void resetZoom({bool animated = true}) {
    _rect = null;
    _zoomAnimated = true;
    _state?._resetZoom(animated: animated);
  }
}

class CxTextureState extends State<CxTexture> with SingleTickerProviderStateMixin, WidgetsBindingObserver{

  final TransformationController _transformationController = TransformationController();
  late AnimationController _animationController;
  Offset? _lastFocalPoint;
  double _targetScale = 1.0;
  Matrix4 _targetMatrix = Matrix4.identity();

  double baseScaleX = 1;//这两个缩放因子是用来修正宽高比的,修正完后默认是BoxFit.contain模式，两个缩放因子一定是一个为1，另一个小于1
  double baseScaleY = 1;//
  double fitScale = 1;
  double defaultScale = 1;
  Matrix4 _baseMatrix = Matrix4.identity();
  Size? oldSize;

  double _selectScale = 0;
  EdgeInsets zoomBoundaryMargin = EdgeInsets.zero;
  Matrix4 _zoomMatrix = Matrix4.identity();
  Offset? _lastContentPoint;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      if(getSize() != oldSize) {
        _correctAndFit();
        if (widget._rect != null) {
          _zoomToRect(widget._rect!, animated: widget._zoomAnimated);
        }
      }
    });
    WidgetsBinding.instance.addObserver(this);

    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    )..addListener(_handleAnimationUpdate);
  }

  @override
  void didUpdateWidget(covariant CxTexture oldWidget) {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
        _correctAndFit();
        if (widget._rect != null) {
          _zoomToRect(widget._rect!, animated: widget._zoomAnimated);
        }
    });
    super.didUpdateWidget(oldWidget);
  }

  @override
  void didChangeDependencies() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      if(getSize() != oldSize) {
        _correctAndFit();
        if (widget._rect != null) {
          _zoomToRect(widget._rect!, animated: widget._zoomAnimated);
        }
      }
    });
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _animationController.dispose();
    super.dispose();
  }

  @override
  void didChangeMetrics() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      if(getSize() != oldSize) {
        _correctAndFit();
        if (widget._rect != null) {
          _zoomToRect(widget._rect!, animated: widget._zoomAnimated);
        }
      }
    });
    super.didChangeMetrics();
  }

  void _handleAnimationUpdate() {
    _transformationController.value = Matrix4Tween(
      begin: _transformationController.value,
      end: _targetMatrix,
    ).animate(_animationController).value;
  }

  double get _currentScale {
    return _transformationController.value.getMaxScaleOnAxis();
  }

  void _handleDoubleTapDown(TapDownDetails details) {
    _lastFocalPoint = details.localPosition;
    _lastContentPoint = _selectScale > 0 ? _contentPointForView(_lastFocalPoint) : null;
  }

  Future<void> _handleDoubleTap() async {
    if (_lastFocalPoint == null) return;

    if(_currentScale >= 3.0){
      _targetScale = _selectScale > 0 ? _selectScale : 1.0;
    }else if(_currentScale >= 2.0){
      _targetScale = 3.0;
    }else {
      _targetScale = 2.0;
    }

    _updateTargetMatrix();
    _animationController.reset();
    await _animationController.forward();
  }

  Offset? _contentPointForView(Offset? viewPoint){
    if(viewPoint == null) return null;

    final Matrix4 transformationInv = _transformationController.value.clone();
    try{
      transformationInv.invert();
    }catch(e){
      return viewPoint;
    }

    final Vector3 res = transformationInv.transform3(Vector3(viewPoint.dx, viewPoint.dy, 0));
    return Offset(res.x, res.y);
  }

  void _updateTargetMatrix() {
    if (_targetScale == 1.0) {
      _targetMatrix = Matrix4.identity();
    } else if (_targetScale == _selectScale) {
      _targetMatrix = _zoomMatrix;
    } else if (_lastContentPoint != null) {
      _targetMatrix = Matrix4.identity()
        ..translate(_lastFocalPoint!.dx, _lastFocalPoint!.dy)
        ..scale(_targetScale)
        ..translate(-_lastContentPoint!.dx, -_lastContentPoint!.dy);
    } else if (_lastFocalPoint != null) {
      _targetMatrix = Matrix4.identity()
        ..translate(_lastFocalPoint!.dx, _lastFocalPoint!.dy)
        ..scale(_targetScale)
        ..translate(-_lastFocalPoint!.dx, -_lastFocalPoint!.dy);
    }
  }

  void _correctAndFit(){
    if(!mounted) return;
    final size = getSize();
    if(size == null || size.isEmpty) return;
    oldSize = size;
    _correctRatio(size);
    _applyFitScale(size);
    // if(!size.isEmpty){
      Offset center = size.center(Offset.zero);
      _baseMatrix = Matrix4.identity()
        ..translate(center.dx, center.dy)
        ..scale(baseScaleX * fitScale, baseScaleY * fitScale)
        ..translate(-center.dx, -center.dy);
    // }
    if(mounted){
      setState(() {

      });
    }
  }

  Size? getSize(){
    try{
      return context.size;
    }catch(e){
      CLog.e("[CxTexture] getSize error, do not setFit in widget build!");
    }
    return null;
  }

  void _correctRatio(Size viewSize){
    if(viewSize.isEmpty) return;
    if(viewSize.aspectRatio > widget._videoRatio){
      baseScaleX = widget._videoRatio/viewSize.aspectRatio;
      baseScaleY = 1;
    }else{
      baseScaleX = 1;
      baseScaleY = viewSize.aspectRatio/widget._videoRatio;
    }
  }

  void _applyFitScale(Size viewSize){
    if(widget._fit == BoxFit.cover){
      if(baseScaleX > baseScaleY){
        // fitScale = baseScaleX/baseScaleY;
        defaultScale = baseScaleX/baseScaleY;
      }else{
        // fitScale = baseScaleY/baseScaleX;
        defaultScale = baseScaleY/baseScaleX;
      }
    }else {
      // fitScale = 1;
      defaultScale = 1;
    }
    Offset center = viewSize.center(Offset.zero);
    _transformationController.value = Matrix4.identity()
      ..translate(center.dx, center.dy)
      ..scale(defaultScale)
      ..translate(-center.dx, -center.dy);
  }

  void _onInteractionEnd(ScaleEndDetails details){
    final size = getSize();
    if(size == null || size.isEmpty) return;

    final matrix = _transformationController.value.clone();
    final translation = matrix.getTranslation();

    final topLeft = _baseMatrix.transform3(Vector3(0, 0, 0));
    final bottomRight = _baseMatrix.transform3(Vector3(size.width, size.height, 0));
    final newTopLeft = matrix.transform3(Vector3(topLeft.x, topLeft.y, 0));
    final newBottomRight = matrix.transform3(Vector3(bottomRight.x, bottomRight.y, 0));

    final videoRect = Rect.fromLTRB(newTopLeft.x, newTopLeft.y, newBottomRight.x, newBottomRight.y);

    bool needReset = false;
    if(videoRect.height <= size.height){
      final willTop = (size.height - videoRect.height)/2.0;
      if((videoRect.top - willTop).abs() > 0.1){
        needReset = true;
        matrix.setTranslationRaw(translation.x, translation.y - (videoRect.top - willTop), translation.z);
      }
    } else {
      if (videoRect.top > 0) {
        needReset = true;
        matrix.setTranslationRaw(
            translation.x, translation.y - videoRect.top, translation.z);
      } else if(videoRect.bottom < size.height){
        needReset = true;
        matrix.setTranslationRaw(
            translation.x, translation.y + (size.height - videoRect.bottom), translation.z);
      }
    }

    if(videoRect.width <= size.width){
      final willLeft = (size.width - videoRect.width)/2.0;
      if((videoRect.left - willLeft).abs() > 0.1){
        needReset = true;
        matrix.setTranslationRaw(translation.x - (videoRect.left - willLeft), matrix.getTranslation().y, translation.z);
      }
    } else {
      if (videoRect.left > 0) {
        needReset = true;
        matrix.setTranslationRaw(
            translation.x - videoRect.left, matrix.getTranslation().y, translation.z);
      }else if(videoRect.right < size.width){
        needReset = true;
        matrix.setTranslationRaw(
            translation.x + (size.width - videoRect.right), matrix.getTranslation().y, translation.z);
      }
    }
    if(needReset){
      _targetMatrix = matrix;
      _animationController.reset();
      _animationController.forward();
    }
  }

  void _zoomToRect(Rect normRect, {bool animated = true}){
    if(!mounted) return;

    final size = getSize();
    if(size == null || size.isEmpty) return;

    final videoWidth = size.width * baseScaleX;
    final videoHeight = size.height * baseScaleY;
    var left = normRect.left * videoWidth;
    var top = normRect.top * videoHeight;
    if (videoWidth < size.width) {
      left = left + (size.width - videoWidth) * 0.5;
    }else {
      top = top + (size.height - videoHeight) * 0.5;
    }
    final rect = Rect.fromLTWH(left, top, normRect.width * videoWidth, normRect.height * videoHeight);

    final center = size.center(Offset.zero);
    final rectCenter = rect.center;
    final rectWidth = rect.width;
    final rectHeight = rect.height;
    if(rectWidth <= 0 || rectHeight <= 0) return;

    final scaleX = size.width / rectWidth;
    final scaleY = size.height / rectHeight;
    final scale = widget._fit == BoxFit.cover ? math.max(scaleX, scaleY) : math.min(scaleX, scaleY);

    _selectScale = scale;

    _targetMatrix = Matrix4.identity()
      ..translate(center.dx, center.dy)
      ..scale(scale)
      ..translate(-rectCenter.dx, -rectCenter.dy);

    _zoomMatrix = _targetMatrix.clone();

    if(animated){
      _animationController.reset();
      _animationController.forward();
    } else {
      _transformationController.value = _targetMatrix;
    }

    setState(() {
      zoomBoundaryMargin = EdgeInsets.fromLTRB(-rect.left, -rect.top, rect.right-size.width, rect.bottom-size.height);
    });
  }

  void _resetZoom({bool animated = true}){
    if(!mounted) return;

    _selectScale = 0;

    _targetMatrix = Matrix4.identity();
    _zoomMatrix = Matrix4.identity();

    if(animated){
      _animationController.reset();
      _animationController.forward();
    } else {
      _transformationController.value = _targetMatrix;
    }

    setState(() {
      zoomBoundaryMargin = EdgeInsets.zero;
    });
  }

  @override
  Widget build(BuildContext context) {
    // CLog.d("${widget._textureId} build videoRatio:${widget._videoRatio}");
    if(widget._textureId != null){
      return GestureDetector(
        onDoubleTapDown: _handleDoubleTapDown,
        onDoubleTap: _handleDoubleTap,
        child: InteractiveViewer(
            transformationController: _transformationController,
            interactionEndFrictionCoefficient:double.infinity,
            onInteractionEnd: _onInteractionEnd,
            minScale: _selectScale > 0 && _selectScale <= 3 ? _selectScale : 1.0,
            maxScale: 3.0,
            boundaryMargin: zoomBoundaryMargin,
            child: Transform.scale(
              scaleX: baseScaleX * fitScale,
              scaleY: baseScaleY * fitScale,
              child: Texture(textureId: widget._textureId!,),
            ),
        ),
      );
    }else{
      return const SizedBox();
    }
  }
}
