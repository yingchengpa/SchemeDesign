import 'package:dio/dio.dart';
import './CLog.dart';
import 'package:upservice/dio/uhome_dio/uhome_request_options.dart';
import 'package:user/modle/oauth_data_model.dart';
import 'package:user/modle/user_info_model.dart';
import 'package:user/user.dart';

///云端文档https://ihaier.feishu.cn/wiki/wikcn66IDHc2BtKK7p55jeqxkzW
class HttpApi{
  static final _instance = HttpApi._();
  static HttpApi get instance => _instance;
  late Dio dio;

  HttpApi._(){
    dio = Dio();
    //dio的配置无非两大块，options和interceptors
    //点开UhomeDio的代码我们可以看到它都添加了那些修改
    //因为它拦截器直接替换了baseUrl为https://zj.haier.net,所以我们不能用它的拦截器，另外options也没有什么我们需要的，所以我们完全自己新建Dio
    //我们需要UhomeDio为我们添加appId、clientId、userId、accessToken的header，以及签名，这些功能在UhomeRequestOptions().header里，我们放在拦截器UwsInterceptor里调用
    // dio = Dio(UhomeDio().dio.options);
    // dio.interceptors.addAll(UhomeDio().dio.interceptors);
    dio.options.baseUrl = 'https://uws.haier.net';//uws要求签名的时候排除域名，所以我们必须把baseUrl单独拎出来
    dio.options.headers['apiVersion'] = 'v1';
    // dio = UhomeDio().dio;

    //UhomeDio()自带的Interceptor总是把userId、accessToken加不进去，所以我们自己加个拦截器加
    dio.interceptors.add(UwsInterceptor());
    //LogInterceptor一定要放后面
    dio.interceptors.add(LogInterceptor(
        request: true,
        requestHeader: true,
        requestBody: true,
        responseHeader: true,
        responseBody: true,
        error: true,
        logPrint: (object) {
          CLog.i('[HttpApi] ' + object.toString());
        }));
  }

  ///https://ihaier.feishu.cn/wiki/wikcn66IDHc2BtKK7p55jeqxkzW
  ///返回：{"payload":{"appId":"Haier_App","devAuthInfo":"eb71710827c3586ae1e26d619b30b016e0d9aaebf8fb0da23a1809fdc9b1b51d","deviceName":"XHX1IVCNI96WPIMA","productId":"3d82af0314c0e29e","productSign":"11daf8a545479a0723004859aa926571:dyg7mU/V4MSHHsYFxP7/sScSDtA=","randomNumber":2127322298,"timeStamp":1733971209},"retCode":"00000","retInfo":"成功"}
  Future<String?> getDeviceLiveAccess(String deviceId)async{
    try {
      Map params = {'deviceId': deviceId};//参数必须是Map，否则UhomeRequestOptions内进行签名的时候会把body换成空
      Response<String> response = await dio.post<String>(
          '/rcs/avm/video/device/temp-access', data: params,);
      int? statusCode = response.statusCode;
      if (statusCode != null && statusCode >= 200 && statusCode < 300) {
        return response.data.toString();
      }
    }catch(e){
      CLog.e('[HttpApi] getDeviceLiveAccess e:',e);
    }
    return null;
  }

  ///https://ihaier.feishu.cn/wiki/wikcn66IDHc2BtKK7p55jeqxkzW
  ///云端返回有刷新时间，我们要每隔1/3刷新时间请求更新这个，合理吗？ ———— 360贾工说keys列表里设置一次就可以
  ///返回：{"payload":{"deviceId":"EFJ5SKOI65","keys":[351,352,353,354,355,356,357,358,359,360],"refreshInterval":259200,"values":["05e751f49f6a4b8f8639c998c666890e","15d31dd381664894aaf3c4863fdbfee6","0ecf1ac8419c4308a68608b946bd71cb","3151a8c5551b43cf8fe5d4386c4fd853","39ec757fdda546009a84692bbf4bb858","26594ba6218d44338f8457e7ec1f4895","95aadde5305541a98ea8a0e255b69b73","2636221ecff1400cbcae3d66e7c87ba5","1e8cac4dfb5546c7804c6f33601fb2a8","f0d1f1692b6e48679f64982ff7d0727f"]},"retCode":"00000","retInfo":"成功"}
  Future<String?> getDeviceLiveSecret(String deviceId) async{
    try {
      Map params = {'deviceId': deviceId};
      Response<String> response = await dio.post<String>(
          '/rcs/avm/video/app/get-decode-secret-key', data: params);
      int? statusCode = response.statusCode;
      if (statusCode != null && statusCode >= 200 && statusCode < 300) {
        return response.data.toString();
      }
    }catch(e){
      CLog.e('[HttpApi] getDeviceLiveSecret e:',e);
    }
    return null;
  }

}

class UwsInterceptor extends Interceptor{

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) async{
    try{
      //Map<String,dynamic> headers = {};
      var headers = await UhomeRequestOptions().header(options);
      //CLog.d('onRequest headers:$headers');
      //实测userId和accessToken可能为空，进入UhomeRequestOptions().header代码可以看到为空的原因，我们这里做个补充
      var userId = headers['userId'];
      if(userId == null || userId == ''){
        final UserInfo userInfo = await User.getUserInfo();
        headers['userId'] = userInfo.userId;
      }
      var accessToken = headers['accessToken'];
      if(accessToken == null || accessToken == ''){
        OauthData oauthData = await User.getOauthData();
        headers['accessToken'] = oauthData.uhome_access_token;
      }
      headers['sequenceId'] = headers['timestamp']?.toString();
      options.headers.addAll(headers);

    }catch(e){
      CLog.e('[UwsInterceptor] onRequest e:$e');
    }
    super.onRequest(options, handler);
  }
}

class UwsRetCode{
  static const OK = '00000';
}
