/// 常量、错误码定义,必须和原生三端统一

const kEventName = 'eventName';
const kEventType = 'eventType';
const kEventData = 'eventData';

const kErrorCode = 'code';
const kErrorMsg = 'message';
const kErrorDetail = 'detail';

const kPlayerEvent = 'playerEvent';
const kPlayerError = 'playerError';
const kPlayerProgress = 'progress';
const kPlayerDuration = 'duration';
const kPlayerState = 'state';
const kPlayerBitrate = 'bitrate';
const kPlayerVideoSizeChanged = 'videoSizeChanged';
const kPlayerStuck = 'stuck';
const kPlayerTalkingVolume = "talkingVolume";

const kRecordEvent = 'recordEvent';
const kRecordError = 'recordError';

const kSnapshotEvent = 'snapshotEvent';
const kSnapshotError = 'snapshotError';

const kDownloadProgress = 'downloadProgress';
const kDownloadState = 'downloadState';

/// CxPlayer错误码, 和原生侧统一
const cxplayerNoErrorCode = 0;
const cxplayerCommonErrorCode = 900000;
const cxplayerParamsErrorCode = 900003;

// 全局初始化器相关
const cxplayerGlobalInitErrorCode = 910001;
const cxplayerDeviceInfoInviladCode = 910002;
const cxplayerDeviceInfoExpiredCode = 910003;
const cxplayerDeviceInfoInviladIOS = 110005;

// NetGodSees相关
const cxplayerSessionIdInvalidCode = 920001;
const cxplayerCreateSessionErrorCode = 920002;
const cxplayerPullStreamErrorCode = 920003;

// 播放器相关
const cxplayerInitErrorCode = 930001;
const cxplayerReleasedCode = 930002;
const cxplayerUrlIsNullCode = 930003;
const cxplayerPlayTimeoutCode = 930004;
const cxplayerPlayErrorCode = 930005;
const cxplayerGetRecordListErrorCode = 930006;

// RTC相关

// downloader相关
