import 'dart:async';
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import './CLog.dart';
import './http_api.dart';
import 'package:user/modle/user_info_model.dart';
import 'package:user/user.dart';

class DeviceLiveInfoRepo {
  static final DeviceLiveInfoRepo _instance = DeviceLiveInfoRepo._();

  static DeviceLiveInfoRepo get instance => _instance;

  static const int validTime = 1000 * 60 * 60 * 8;

  DeviceLiveInfoRepo._() {
    _readLocalLiveInfoFuture = _readLocalLiveInfo();
  }

  final Map<String, String> deviceLiveInfoCache = {};
  final Map<String, int> deviceLiveInfoTime = {};

  Future<void>? _readLocalLiveInfoFuture;
  final Map<String, Future<String?>?> _getRemoteInfoFuture = {};

  Future<String?> getDeviceLiveInfo(String deviceId, {bool forceRemote = false}) async {
    if (_getRemoteInfoFuture.containsKey(deviceId)) {
      CLog.d('[DeviceLiveInfoRepo] getDeviceLiveInfo deviceId:$deviceId return existed future');
      return _getRemoteInfoFuture[deviceId];
    }
    final future = getDeviceLiveInfoInternal(deviceId, forceRemote: forceRemote);
    future.then((value) {
      //CLog.d('getDeviceLiveInfo then');
      _getRemoteInfoFuture.remove(deviceId);
    }, onError: (error) {
      //CLog.d('getDeviceLiveInfo onError');
      _getRemoteInfoFuture.remove(deviceId);
    });
    _getRemoteInfoFuture[deviceId] = future;
    return future;
  }

  deleteDeviceLiveInfoCache(String deviceId) {
    deviceLiveInfoCache.remove(deviceId);
    deviceLiveInfoTime.remove(deviceId);
    _writeLiveInfo2Local();
  }

  //TODO 这个缓存到底多久过期？
  //主要两部分:
  // 一、用于拉流的devAuthInfo,过期会造成设备验证失败，拒绝推流，实测有时候这个很快就过期， 陈毅：这个是通过IOT的Localkey生成的，更新逻辑在OSDK里面，贾守强：localkey 8小时有效期，
  // 我希望接口能返回devAuthInfo的过期时间：陈毅， 实测：现在返回的timeStamp就是当前时间戳，每次都会变，没有用
  // 二、 用于解密的keys和values, 10组秘钥，没过一个周期（之前是1小时，后来改成了72小时——陈毅） 移除第一个，再新增一个
  //
  Future<String?> getDeviceLiveInfoInternal(String deviceId, {bool forceRemote = false}) async {
    CLog.i('[DeviceLiveInfoRepo] getDeviceLiveInfo deviceId:$deviceId');
    //等待读取本地缓存
    if (_readLocalLiveInfoFuture != null) {
      CLog.i('[DeviceLiveInfoRepo] getDeviceLiveInfo wait read local');
      await _readLocalLiveInfoFuture;
    }
    if (deviceLiveInfoCache.containsKey(deviceId) && !forceRemote) {
      final time = deviceLiveInfoTime[deviceId];
      if (time != null && DateTime.now().millisecondsSinceEpoch - time < validTime) {
        CLog.i('[DeviceLiveInfoRepo] getDeviceLiveInfo deviceId:$deviceId use cache');
        return deviceLiveInfoCache[deviceId];
      } else {
        deviceLiveInfoCache.remove(deviceId);
        deviceLiveInfoTime.remove(deviceId);
        _writeLiveInfo2Local();
      }
    }
    String? result;
    try {
      var ret = await Future.wait<String?>(
          [HttpApi.instance.getDeviceLiveAccess(deviceId), HttpApi.instance.getDeviceLiveSecret(deviceId)]);

      var accessJ = ret[0];
      var secretJ = ret[1];
      if (accessJ != null && secretJ != null) {
        var access = jsonDecode(accessJ);
        var secret = jsonDecode(secretJ);
        var retCode = access['retCode'];
        var retCode2 = secret['retCode'];
        if (retCode == UwsRetCode.OK && retCode2 == UwsRetCode.OK) {
          final UserInfo userInfo = await User.getUserInfo();
          var map = {'access': access, 'secret': secret, 'userId': userInfo.userId};
          result = jsonEncode(map);
          deviceLiveInfoCache[deviceId] = result;
          deviceLiveInfoTime[deviceId] = DateTime.now().millisecondsSinceEpoch;
          _writeLiveInfo2Local();
        }
      }
    } catch (e) {
      CLog.e('[DeviceLiveInfoRepo] getDeviceLiveInfo ', e);
    }
    return result;
  }

  Future<void> _readLocalLiveInfo() async {
    try {
      SharedPreferences sp = await SharedPreferences.getInstance();
      final liveInfoJson = sp.getString("deviceLiveInfoMapJson");
      final liveInfoTimeJson = sp.getString("deviceLiveInfoTimeMapJson");
      if (liveInfoJson != null && liveInfoTimeJson != null) {
        Map<String, dynamic> liveInfoMapTemp = jsonDecode(liveInfoJson);
        Map<String, String> liveInfoMap = liveInfoMapTemp.map((key, value) => MapEntry(key, value as String));
        deviceLiveInfoCache.addAll(liveInfoMap);

        Map<String, dynamic> liveInfoTimeMapTemp = jsonDecode(liveInfoTimeJson);
        Map<String, int> liveInfoTimeMap = liveInfoTimeMapTemp.map((key, value) => MapEntry(key, value as int));
        deviceLiveInfoTime.addAll(liveInfoTimeMap);
        CLog.d("[DeviceLiveInfoRepo] _readLocalLiveInfo cache size:${deviceLiveInfoCache.length}");
        //CLog.d("_readLocalLiveInfo time:$deviceLiveInfoTime");
      }
    } catch (e, s) {
      CLog.e('[DeviceLiveInfoRepo] _readLocalLiveInfo $e', s);
    }
    _readLocalLiveInfoFuture = null;
  }

  Future<void> _writeLiveInfo2Local() async {
    try {
      SharedPreferences sp = await SharedPreferences.getInstance();
      sp.setString("deviceLiveInfoMapJson", jsonEncode(deviceLiveInfoCache));
      sp.setString("deviceLiveInfoTimeMapJson", jsonEncode(deviceLiveInfoTime));
    } catch (e) {
      CLog.e('[DeviceLiveInfoRepo] _writeLiveInfo2Local ', e);
    }
  }
}
