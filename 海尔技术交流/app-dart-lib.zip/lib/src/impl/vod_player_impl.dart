import 'dart:async';

import 'package:cx_player/cx_player.dart';
import 'package:qihoo_player/src/impl/base_player_impl.dart';
import 'package:qihoo_player/src/impl/CLog.dart';
import 'package:qihoo_player/src/impl/common.dart';
import 'package:qihoo_player/src/impl/constants.dart';
import 'package:qihoo_player/src/utils/player_tracker.dart';
import 'package:flutter/services.dart';
import 'package:network/isonline.dart';
import 'package:network/network.dart';

class VodPlayer extends BasePlayer implements IVodPlayer {
  late Future<int?> createFuture;
  Uri? _currentUri;
  double _currentSpeed = 1;

  VodPlayer() : super('VodPlayer', PlayerType.vod) {
    init();
  }

  Future<void> init() async {
    CLog.i("[VodPlayer] $deviceId init");
    try {
      isInitRunning = true;
      final value = await CommonMethodChannel.baseChannel.invokeMethod<int>('createVodPlayer');
      CLog.i("[VodPlayer] $deviceId init createVodPlayer result textureId:$value");
      if (value == null) {
        CLog.e("[VodPlayer] $deviceId init createVodPlayer failed, value is null");
        currentPlayException = BasePlayException(code: cxplayerInitErrorCode, info: 'VodPlayer init failed');
        playStateStream.add(PlayState.error);
        isInitRunning = false;
        isInited = true;
      } else {
        textureId = value;
        methodChannel = MethodChannel("$channelNameBase/method/$textureId");
        subscribeWithEventChannelName('$channelNameBase/event/$textureId');
        isInitRunning = false;
        isInited = true;
        methodChannelFutureCompleter.complete(methodChannel);
        CLog.i("[VodPlayer] $deviceId init success textureId:$textureId");
      }
    } catch (e) {
      isInited = false;
      CLog.e("[VodPlayer] $deviceId init error:", e);
      currentPlayException = BasePlayException(code: cxplayerInitErrorCode, info: 'VodPlayer init error: $e');
      playStateStream.add(PlayState.error);
    }
  }

  @override
  void onPlayStateEvent(Map<String, dynamic> eventData) {
    final playState = PlayStateMap.instance().convert(eventData[kPlayerState]);
    CLog.i("[VodPlayer] $deviceId eventChannel on event playState:$playState");
    if (playState == PlayState.error) {
      final err = (eventData[kPlayerError] as Map<dynamic, dynamic>).cast<String, dynamic>();
      currentPlayException = BasePlayException(code: err[kErrorCode], info: err[kErrorMsg], detail: err[kErrorDetail]);
      checkPlayError().then((e) {
        PlayerTracker.trackSuccessRate(Stage.play, this, exception: e ?? currentPlayException);
        if (e is! PlayNetworkException) {
          PlayerTracker.trackException(
              ErrorType.play, currentPlayException.code.toString(), currentPlayException.info, currentPlayException.detail);
        }
      });
    } else if (playState == PlayState.playing) {
      PlayerTracker.trackTimeConsumeNode(Node.onPlaying, this);
      PlayerTracker.trackSuccessRate(Stage.play, this);
      if (textureId != -1) {
        cxTexture.setTextureId(textureId);
      } else {
        CLog.e("[VodPlayer] textureId is invalid!");
      }
    }
    if (playState != null) {
      updatePlayState(playState);
    }
  }

  @override
  void onExtraEvent(Map<String, dynamic> eventMap) {
    if (eventMap.containsKey("width")) {
      int width = eventMap['width'];
      int height = eventMap['height'];
      videoSize = Size(width.toDouble(), height.toDouble());
      cxTexture.setVideoRatio(width / height);
      playEventStream.add(VideoSizeChangedEvent());
    }
  }

  @override
  Uri? getCurrentUri() {
    return _currentUri;
  }

  @override
  int getDuration() {
    return duration;
  }

  @override
  double getSpeed() {
    return _currentSpeed;
  }

  @override
  void pause() {
    CLog.i("[VodPlayer] $deviceId pause");
    getMethodChannel().then((channel) {
      channel?.invokeMethod('pause').then((value) {
        updatePlayState(PlayState.paused);
      }).catchError((error) {
        CLog.e('[VodPlayer] $deviceId pause error: $error');
      });
    });
  }

  @override
  void seekTo(int mills) {
    CLog.i("[VodPlayer] $deviceId seekTo mills:$mills");
    getMethodChannel().then((channel) {
      channel?.invokeMethod('seekTo', mills).then((value) {
        CLog.i("[VodPlayer] $deviceId seekTo success");
      }).catchError((error) {
        CLog.e('[VodPlayer] $deviceId seekTo error:', error);
      });
    });
  }

  @override
  void setSpeed(double speed) {
    CLog.i("[VodPlayer] $deviceId setSpeed speed:$speed");
    getMethodChannel().then((channel) {
      channel?.invokeMethod('setSpeed', speed).then((value) {
        _currentSpeed = speed;
        CLog.i("[VodPlayer] $deviceId setSpeed success currentSpeed:$_currentSpeed");
      }).catchError((error) {
        CLog.e('[VodPlayer] $deviceId setSpeed error:', error);
      });
    });
  }

  @override
  void startPlay() {
    CLog.i("[VodPlayer] $deviceId startPlay");
    updatePlayState(PlayState.loading);
    getMethodChannel().then((channel) {
      PlayerTracker.trackTimeConsumeNode(Node.onStartPlay, this);
      channel?.invokeMethod('startPlay').catchError((error) {
        CLog.e('[VodPlayer] $deviceId startPlay error: $error');
      });
    });
  }

  @override
  void startPlayUri(Uri videoUri) {
    CLog.i('[VodPlayer] $deviceId startPlayUri uri:$videoUri');
    updatePlayState(PlayState.loading);
    deviceId = 'VodPlayer ${videoUri.pathSegments.last}';
    _currentUri = videoUri;
    getMethodChannel().then((channel) {
      PlayerTracker.trackTimeConsumeNode(Node.onStartPlay, this);
      channel?.invokeMethod("startPlayUri", videoUri.toString()).then((value) {
        CLog.i('[VodPlayer] $deviceId startPlayUri native method success');
      }).catchError((error) {
        CLog.e('[VodPlayer] $deviceId startPlayUri error:', error);
        updatePlayState(PlayState.error);
      });
    });
  }

  @override
  void resume() {
    CLog.i("[VodPlayer] $deviceId resume");
    getMethodChannel().then((channel) {
      channel?.invokeMethod('resume').then((value) {
        updatePlayState(PlayState.playing);
      }).catchError((error) {
        CLog.e('[VodPlayer] $deviceId resume error: $error');
      });
    });
  }

  @override
  Future<BasePlayException?> checkPlayError() async {
    final NetworkStatus networkStatus = await Network.isOnline();
    bool isNetworkAvailable = networkStatus.isOnline;
    BasePlayException? exception;
    if (!isNetworkAvailable) {
      //是否没网
      exception = PlayNetworkException();
    }
    return exception;
  }
}
