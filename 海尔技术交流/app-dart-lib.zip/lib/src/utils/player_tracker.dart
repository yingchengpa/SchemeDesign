import 'package:crashlog/crashlog.dart';
import 'package:crashlog/model/crashlog_model.dart';
import 'package:qihoo_player/src/impl/CLog.dart';
import 'package:qihoo_player/src/impl/vod_player_impl.dart';
import 'package:cx_player/cx_player.dart';
import 'package:flutter/services.dart';
import 'package:plugin_device/plugin/updevice_plugin.dart';
import 'package:trace/trace.dart';
import 'package:qihoo_player/src/impl/base_player_impl.dart';

class PlayerType {
  static const live = 'live';
  static const record = 'record';
  static const vod = 'vod';
}

enum ErrorType { play, snap, record, talk, setVideoDefinition, loadRecordList, cloudRecordDownload, getVideoDefinition }

const playResultEvent = 'MBTI66001'; // 音视频-播放成功失败
const wakeupResultEvent = 'MBTI66002'; // 音视频-唤醒成功失败
const getRecordListResultEvent = 'MBTI66003'; // 音视频-卡录列表获取成功失败
const pullStreamDurationEvent = 'MBTI66104'; // 音视频-开流耗时
const playerFeatureEvent = 'MBTI66201'; // 音视频-功能使用

const snapshotFeature = '截屏';
const recordFeature = '录像';
const talkFeature = '对讲';
const definitionFeature = '切换清晰度';
const downloadFeature = '云录像下载';

enum Stage { play, wakeup, getRecordList }

enum Node { onStartPlay, onPlaying }

class PlayerTracker {
  static final _stage2Event = {
    Stage.play: playResultEvent,
    Stage.wakeup: wakeupResultEvent,
    Stage.getRecordList: getRecordListResultEvent,
  };

  static final _nodes = {
    PlayerType.live: <Node, int>{},
    PlayerType.record: <Node, int>{},
    PlayerType.vod: <Node, int>{},
  };

  static String _getStageEvent(Stage stage) {
    return _stage2Event[stage]!;
  }

  static void trackException(ErrorType type, String errorCode, String? simpleInfo, String? detailInfo) {
    //HC-play-CP:920002-QE:1001
    WriteExceptionModel exception =
    WriteExceptionModel("HC/${type.name}/CP:${errorCode}/${simpleInfo??""}",detailInfo??"--");//reason参数不能为""，否则报错
    CLog.d("[PlayerTracker] trackException: ${exception.toString()}");
    final result = Crashlog.writeException(exception);
    if (result is Future) {
      result.then((v) {
        CLog.d("[PlayerTracker] trackException result: $v");
      });
    }
  }

  static void trackExceptionWithError(ErrorType type, Object e) {
    if (e is PlatformException) {
      trackException(type, e.code, e.message, e.details);
    } else {
      trackException(type, "-1", "", e.toString());
    }
  }

  /// 成功率打点
  static Future<void> trackSuccessRate(
    Stage stage,
    IPlayer player, {
    BasePlayException? exception,
  }) async {
    final basePlayer = player as BasePlayer;
    Map<String, dynamic> params = {
      'source': 'Flutter',
      'playerType': basePlayer.playerType,
      'code': exception?.code.toString() ?? '0',
      'isFirst': BasePlayer.isFirstLivePlay ? '1' : '0',
    };

    if (basePlayer is! VodPlayer) {
      final deviceInfo = await UpDevicePlugin.getDeviceInfoById(basePlayer.deviceId);
      params['prodNo'] = deviceInfo.prodNo;
      params['model'] = deviceInfo.model;
    }

    if (exception != null) {
      params['info'] = exception.info;
    }
    Trace.traceEventWithVariable(eventId: _getStageEvent(stage), variable: params);
  }

  /// 开流耗时打点
  static Future<void> trackTimeConsumeNode(Node node, IPlayer player) async {
    BasePlayer basePlayer = player as BasePlayer;
    _nodes[basePlayer.playerType]?[node] = DateTime.now().millisecondsSinceEpoch;
    if (node != Node.onPlaying) {
      return;
    }

    final start = _nodes[basePlayer.playerType]?[Node.onStartPlay];
    _nodes[basePlayer.playerType]?.clear();
    if (start == null) {
      CLog.i("trackTimeConsume onPlaying,but has no onStartPlay time.");
      return;
    }

    final tc = DateTime.now().millisecondsSinceEpoch - start;

    final params = {
      'source': 'Flutter',
      'playerType': basePlayer.playerType,
      'duration': tc,
      'isFirst': BasePlayer.isFirstLivePlay ? '1' : '0',
    };

    if (basePlayer is! VodPlayer) {
      final deviceInfo = await UpDevicePlugin.getDeviceInfoById(basePlayer.deviceId);
      params['prodNo'] = deviceInfo.prodNo;
      params['model'] = deviceInfo.model;
    }
    CLog.i("trackTimeConsume $params");
    Trace.traceEventWithVariable(eventId: pullStreamDurationEvent, variable: params);
  }

  /// 功能使用打点
  static void trackFeatureUseage(String feature) {
    Trace.traceEventWithVariable(eventId: playerFeatureEvent, variable: {'content_type': feature});
  }
}
