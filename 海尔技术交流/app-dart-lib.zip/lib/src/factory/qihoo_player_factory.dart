// qihoo_player/lib/src/factory/qihoo_player_factory.dart
import 'package:cx_player/cx_player.dart';
import '../impl/common.dart';
import '../impl/CLog.dart';
import '../impl/live_player_impl.dart';
import '../impl/local_record_player_impl.dart';
import '../impl/vod_player_impl.dart';
import '../impl/cloud_record_downloader_impl.dart';
import '../impl/device_live_info_repo.dart';

/// 360 播放器工厂实现
class QihooPlayerFactory implements IPlayerFactory {
  @override
  String get playerType => 'qihoo';

  @override
  ILivePlayer createLivePlayer(String deviceId, {bool isDual = false, bool isReverse = false}) {
    return LivePlayer(deviceId, isDual: isDual, isReverse: isReverse);
  }

  @override
  ILocalRecordPlayer createLocalRecordPlayer(String deviceId,
      {bool isDual = false, bool isReverse = false, bool isSupportAov = false}) {
    return LocalRecordPlayer(deviceId, isDual: isDual, isReverse: isReverse, isSupportAov: isSupportAov);
  }

  @override
  IVodPlayer createVodPlayer() {
    return VodPlayer();
  }

  @override
  ICloudRecordDownloader createCloudRecordDownloader(String videoUri, String dirPath) {
    return CloudRecordDownloader(videoUri, dirPath);
  }

  @override
  Future<void> preConnect(String deviceId) async {
    final future = DeviceLiveInfoRepo.instance.getDeviceLiveInfo(deviceId);
    future.then((deviceLiveInfo) {
      if (deviceLiveInfo != null) {
        try {
          CommonMethodChannel.baseChannel.invokeMethod('preConnect', deviceLiveInfo).catchError((error){
            CLog.e("[preConnect]  exception", error);
          });
        } catch (e) {
          CLog.e("[preConnect] exception", e);
        }
      } else {
        CLog.e("[preConnect] but liveInfo is null!");
      }
    });
  }
  
  @override
  Future<String?> saveLogFile() async {
    try {
      return await CommonMethodChannel.baseChannel.invokeMethod<String>('saveLog');
    } catch (e) {
      return null;
    }
  }
}
