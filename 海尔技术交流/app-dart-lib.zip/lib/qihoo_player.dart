// qihoo_player/lib/qihoo_player.dart
library qihoo_player;

export 'src/factory/qihoo_player_factory.dart';
export 'src/utils/player_tracker.dart';

import 'package:cx_player/cx_player.dart';
import 'src/factory/qihoo_player_factory.dart';

/// 360 播放器注册入口
class QihooPlayer {
  /// 注册 360 播放器工厂到 VideoPlayerManager
  static void register() {
    VideoPlayerManager().registerFactory(QihooPlayerFactory());
  }
}
